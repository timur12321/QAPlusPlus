﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QAChallenge2IfElse_GA
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("*********** Hello welcome to QA++ ***********");

            Console.WriteLine("Please enter your age:");
          
            int age = Convert.ToInt32(Console.ReadLine());

            if (age >= 21)
            {
                Console.WriteLine("Hooraay, you can join us in for QA drinks");
                Console.ReadLine();
            }
            else 
            {
                Console.WriteLine("Hmm.. Sorry, you are too young to come for QA drinks");
                Console.ReadLine();
            }
        }
    }
}
